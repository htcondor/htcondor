/**
 * UniverseType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.3 Oct 05, 2005 (05:23:37 EDT) WSDL2Java emitter.
 */

package condor;

public class UniverseType implements java.io.Serializable {
    private java.lang.String _value_;
    private static java.util.HashMap _table_ = new java.util.HashMap();

    // Constructor
    protected UniverseType(java.lang.String value) {
        _value_ = value;
        _table_.put(_value_,this);
    }

    public static final java.lang.String _STANDARD = "STANDARD";
    public static final java.lang.String _PVMUNIVERSE = "PVMUNIVERSE";
    public static final java.lang.String _VANILLA = "VANILLA";
    public static final java.lang.String _SCHEDULER = "SCHEDULER";
    public static final java.lang.String _MPI = "MPI";
    public static final java.lang.String _GLOBUS = "GLOBUS";
    public static final java.lang.String _JAVA = "JAVA";
    public static final UniverseType STANDARD = new UniverseType(_STANDARD);
    public static final UniverseType PVMUNIVERSE = new UniverseType(_PVMUNIVERSE);
    public static final UniverseType VANILLA = new UniverseType(_VANILLA);
    public static final UniverseType SCHEDULER = new UniverseType(_SCHEDULER);
    public static final UniverseType MPI = new UniverseType(_MPI);
    public static final UniverseType GLOBUS = new UniverseType(_GLOBUS);
    public static final UniverseType JAVA = new UniverseType(_JAVA);
    public java.lang.String getValue() { return _value_;}
    public static UniverseType fromValue(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        UniverseType enumeration = (UniverseType)
            _table_.get(value);
        if (enumeration==null) throw new java.lang.IllegalArgumentException();
        return enumeration;
    }
    public static UniverseType fromString(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        return fromValue(value);
    }
    public boolean equals(java.lang.Object obj) {return (obj == this);}
    public int hashCode() { return toString().hashCode();}
    public java.lang.String toString() { return _value_;}
    public java.lang.Object readResolve() throws java.io.ObjectStreamException { return fromValue(_value_);}
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new org.apache.axis.encoding.ser.EnumSerializer(
            _javaType, _xmlType);
    }
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new org.apache.axis.encoding.ser.EnumDeserializer(
            _javaType, _xmlType);
    }
    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(UniverseType.class);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:condor", "UniverseType"));
    }
    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

}
