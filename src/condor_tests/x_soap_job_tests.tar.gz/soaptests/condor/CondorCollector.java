/**
 * CondorCollector.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.3 Oct 05, 2005 (05:23:37 EDT) WSDL2Java emitter.
 */

package condor;

public interface CondorCollector extends javax.xml.rpc.Service {

/**
 * gSOAP 2.7.6c generated service definition
 */
    public java.lang.String getcondorCollectorAddress();

    public condor.CondorCollectorPortType getcondorCollector() throws javax.xml.rpc.ServiceException;

    public condor.CondorCollectorPortType getcondorCollector(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
