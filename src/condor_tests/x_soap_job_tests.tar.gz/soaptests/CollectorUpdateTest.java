import condor.*;
import java.net.*;

public class CollectorUpdateTest
{
	public static void main(String[] arguments)
		throws Exception
	{
		CondorCollectorLocator locator = new CondorCollectorLocator();
		CondorCollectorPortType port =
			locator.getcondorCollector(new URL(arguments[0]));

		ClassAdStructAttr name = new ClassAdStructAttr();
		name.setName("Name"); name.setType(ClassAdAttrType.value3); name.setValue("FAKE-AD");
		ClassAdStructAttr myaddress = new ClassAdStructAttr();
		myaddress.setName("StartdIpAddr"); myaddress.setType(ClassAdAttrType.value3); myaddress.setValue("<1.2.3.4:4321>");

		ClassAdStructAttr[] attrs =
		{
			name,
			myaddress
		};

		port.insertAd(ClassAdType.value1, attrs);
	}
}
