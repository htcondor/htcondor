import birdbath.Transaction;
import condor.FileInfo;
import condor.UniverseType;
import java.io.File;
import java.io.FileOutputStream;
import junit.framework.AssertionFailedError;

public class ScheddTestCase6
	extends AbstractScheddTestCase
{
	protected void runTest()
		throws Throwable
	{
		Transaction transaction1 = schedd.createTransaction();
		Transaction transaction2 = schedd.createTransaction();

		try
		{
			transaction1.begin(10 * 60);
			transaction2.begin(10 * 60);

			try
			{
				transaction1.commit();
			}
			catch (Exception exception)
			{
			}
		}
		finally
		{
			transaction2.commit();
		}
	}
}
