import java.io.FileOutputStream;

public class ScheddSendBinarySpoolFileTestCase
	extends AbstractScheddSpoolFileTestCase
{
	protected void generate(FileOutputStream testFileOutput)
		throws Exception
	{
		for (int i = 0; i < 257 * 1024; i++)
		{
			testFileOutput.write(i);
		}
	}
}
