import birdbath.*;
import condor.*;
import java.rmi.*;
import java.net.*;
import java.lang.Thread;

import birdbath.Transaction;

public class SubmitExpireTest
{
   public static void main(String[] args)
      throws Throwable
   {
      String schedd_endpoint = System.getProperty("SCHEDD_ENDPOINT");
      Schedd schedd = new Schedd(new URL(schedd_endpoint));

      Transaction transaction1 = schedd.createTransaction();
      transaction1.begin(1);
   }
}

