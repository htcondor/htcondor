#!/usr/bin/env perl
#
# Copyright 2008 Robert Rati
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License. You may
# obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
# WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
# License for the specific language governing permissions and limitations
# under the License.

my $work_dir = "--WORK--";
my $out_dir = "--RESULTS--";
my @jobs;

if ( ! -d $work_dir )
{
  print STDERR "No more work\n";
  exit;
}

# Get the list of jobs
opendir TM, "$work_dir" || die "failed to open $work_dir:$!\n";
foreach my $file (readdir TM) {
	next if $file =~ /^\.\.?$/;
	push @jobs, $file
}
#@jobs = `ls $work_dir`;

if ( $jobs[0] )
{
  chomp ($jobs[0]);
  open (IN, "<$work_dir/$jobs[0]");

  # Write each line of the file to stdout
  while ( <IN> )
  {
    print;
  }
  print "WorkFetchFileName = \"$jobs[0]\"\n";
  close (IN);
  `rm -f $work_dir/$jobs[0]`;
}
