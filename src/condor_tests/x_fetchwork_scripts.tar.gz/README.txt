In order to use the hook scripts for the Condor fetchwork feature, place
the hook scripts in a directory accessible by the user condor will run as
and add appropriate entries to the condor_config configuration file.  Examples
of the configuration entries are provided below.

# Startd hooks
TEST_FETCH_HOOK_FETCH_WORK = <path_to_script>/job_fetch.pl
TEST_FETCH_HOOK_REPLY_CLAIM = <path_to_script>/reply.pl
TEST_FETCH_HOOK_EVICT_CLAIM = <path_to_script>/job_evict.pl

# Starter hooks
TEST_FETCH_HOOK_PREPARE_JOB = <path_to_script>/prepare.pl
TEST_FETCH_HOOK_UPDATE_JOB_INFO = <path_to_script>/update_job_info.pl
TEST_FETCH_HOOK_JOB_EXIT = <path_to_script>/job_exit.pl

SLOT1_JOB_HOOK_KEYWORD = TEST_FETCH
STARTD_JOB_HOOK_KEYWORD = TEST_FETCH
STARTER_JOB_HOOK_KEYWORD = TEST_FETCH

FetchWorkDelay = 10

The scripts provided are based off scripts created by Derek Wright of the
UW Condor Team.

The scripts provided will read files from the /tmp/work directory and output
results to the /tmp/results directory.  All files in the /tmp/results
directory will be named with the same name as the work read in /tmp/work,
but with an appropriately named extension, and tared up for easy
transport/analysis on another machine if desired.  Files in the /tmp/work
directory are to contain ClassAds for Condor, 1 ClassAd per file.
